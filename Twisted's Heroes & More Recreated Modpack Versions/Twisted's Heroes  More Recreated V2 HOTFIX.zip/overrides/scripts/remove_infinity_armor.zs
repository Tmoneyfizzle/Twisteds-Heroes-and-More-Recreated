# Targeted removal for the Avaritia Extreme Crafting Table
<recipetype:avaritia:extreme_crafting>.remove(<item:avaritia:infinity_helmet>);
<recipetype:avaritia:extreme_crafting>.remove(<item:avaritia:infinity_chestplate>);
<recipetype:avaritia:extreme_crafting>.remove(<item:avaritia:infinity_leggings>);
<recipetype:avaritia:extreme_crafting>.remove(<item:avaritia:infinity_boots>);
<recipetype:avaritia:extreme_crafting>.remove(<item:avaritia:infinity_sword>);


# Keep these as a fallback for standard crafting
craftingTable.remove(<item:avaritia:infinity_helmet>);
craftingTable.remove(<item:avaritia:infinity_chestplate>);
craftingTable.remove(<item:avaritia:infinity_leggings>);
craftingTable.remove(<item:avaritia:infinity_boots>);
